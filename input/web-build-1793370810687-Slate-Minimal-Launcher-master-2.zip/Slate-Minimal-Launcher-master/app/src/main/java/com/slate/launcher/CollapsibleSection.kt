package com.slate.launcher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator

/**
 * Connects a tappable [header] to a [body] so that tapping the header slides the body open or
 * closed and rotates the [chevron]. The body's height is animated from 0 to its measured height
 * (or back), so the surrounding layout reflows smoothly instead of jumping.
 *
 * @param initiallyExpanded resting state applied immediately, without animation.
 * @param onStateChanged called with the new expanded state after each user toggle.
 */
class CollapsibleSection(
    header: View,
    private val body: View,
    private val chevron: View?,
    initiallyExpanded: Boolean,
    private val onStateChanged: (Boolean) -> Unit = {}
) {
    var isExpanded: Boolean = initiallyExpanded
        private set

    private var running: ValueAnimator? = null

    init {
        body.visibility = if (isExpanded) View.VISIBLE else View.GONE
        chevron?.rotation = if (isExpanded) 0f else COLLAPSED_ROTATION
        header.isClickable = true
        header.setOnClickListener { toggle() }
    }

    fun toggle() {
        // Clear the reference before cancelling: cancel() fires onAnimationEnd synchronously,
        // and that callback must not hide the body for an animation we are reversing.
        val superseded = running
        running = null
        superseded?.cancel()

        isExpanded = !isExpanded
        onStateChanged(isExpanded)
        animateBody(isExpanded)
        chevron?.animate()
            ?.rotation(if (isExpanded) 0f else COLLAPSED_ROTATION)
            ?.setDuration(ANIM_MS)
            ?.start()
    }

    private fun animateBody(expand: Boolean) {
        val params = body.layoutParams
        val parent = body.parent as? View
        val availableWidth = parent?.let { it.width - it.paddingLeft - it.paddingRight } ?: 0

        if (availableWidth <= 0) {
            // Not laid out yet (only possible before the first frame): nothing to animate from.
            body.visibility = if (expand) View.VISIBLE else View.GONE
            return
        }

        // Natural height of the body at the width it will be laid out at.
        body.measure(
            View.MeasureSpec.makeMeasureSpec(availableWidth, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val target = body.measuredHeight

        val from = if (expand) 0 else body.height
        val to = if (expand) target else 0
        body.visibility = View.VISIBLE

        lateinit var anim: ValueAnimator
        anim = ValueAnimator.ofInt(from, to).apply {
            duration = ANIM_MS
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                params.height = it.animatedValue as Int
                body.layoutParams = params
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    // Ignore ends from an animation that a newer toggle has superseded.
                    if (running !== anim) return
                    running = null
                    if (!expand) body.visibility = View.GONE
                    params.height = ViewGroup.LayoutParams.WRAP_CONTENT
                    body.layoutParams = params
                }
            })
        }
        running = anim
        anim.start()
    }

    private companion object {
        const val ANIM_MS = 220L
        const val COLLAPSED_ROTATION = -90f
    }
}
